# Computer Networks Lab — Cisco Packet Tracer files

One `.pkt` per experiment and sub-experiment from the lab manual. Every file
opens in **Packet Tracer 7.3 and any 8.x release**, and comes with the
topology cabled, all IP addressing applied, and the router/switch
running-configs already saved (also copied to startup-config), so a file is
ready to demonstrate the moment it opens.

| File | Experiment | Devices |
|---|---|---|
| `Ex1a_Study_of_Packet_Tracer.pkt` | 1a Study of network tool | 2960 switch, PC0, PC1 |
| `Ex1b_Simple_LAN_Network.pkt` | 1b Simple LAN | 2960 switch, PC0–PC3, Laptop0, Laptop1 |
| `Ex2a_Peer_to_Peer_Network.pkt` | 2a Peer-to-peer network | 2960 switch, CSE, IT |
| `Ex2b_1_Bus_Topology.pkt` | 2b Bus topology | 3× 2950 switches daisy-chained, 3 PCs |
| `Ex2b_2_Star_Topology.pkt` | 2b Star topology | 2950 switch, 5 PCs |
| `Ex2b_3_Ring_Topology.pkt` | 2b Ring topology | 4× 2950 switches in a ring, 4 PCs |
| `Ex2b_4_Mesh_Topology.pkt` | 2b Mesh topology | 4× 2950 switches fully meshed, 4 PCs |
| `Ex2b_5_Hybrid_Topology.pkt` | 2b Hybrid topology | star core + bus arms, 3 switches, 4 PCs |
| `Ex3a_Network_Commands.pkt` | 3a Network commands | Router, 2 switches, 2 PCs, DNS server |
| `Ex4a_Intra_VLAN.pkt` | 4a Intra-VLAN | S1, S2 (PT switches), PC1–PC8, trunk |
| `Ex4b_a_Inter_VLAN_L3_Switch.pkt` | 4b(a) Inter-VLAN, L3 switch | 3560 multilayer switch, 2× 2960, PC0–PC3 |
| `Ex4b_b_Inter_VLAN_Router_on_a_Stick.pkt` | 4b(b) Router on a stick | Router0, 4 PT switches, PC0–PC8 |
| `Ex5a_Link_State_Routing_OSPF.pkt` | 5a Link state routing | 3 routers (serial), 2 switches, 2 PCs |
| `Ex5b_Distance_Vector_Routing_RIP.pkt` | 5b Distance vector routing | 3 routers (serial), 3 switches, 3 PCs |
| `Ex6_Subnetting.pkt` | 6 Subnetting | Router, 2 switches, 6 PCs, /25 subnets |
| `Ex7_DHCP_Configuration.pkt` | 7 DHCP | Router with 2 pools, 2 switches, 8 DHCP PCs |
| `Ex8_Capture_ICMP_Packets.pkt` | 8 ICMP capture | Router, 2 switches, 2 PCs, server |
| `Ex9a_Capture_TCP_HTTP_DNS_Packets.pkt` | 9a TCP/HTTP/DNS capture | as above + HTTP & DNS services on |
| `Ex10_DNS_FTP_Email_Servers.pkt` | 10 DNS, FTP, Email | Router, 2 switches, PC0, Laptop0, server |

## Addressing, per the manual's tables

- **1a** PC0 172.16.108.25, PC1 172.16.108.26 /16
- **1b** 172.16.103.55–.58 (PCs), .60/.61 (laptops) /16
- **2a** CSE 192.10.10.55, IT 192.10.10.56 /24
- **2b** 192.168.1.0/24 throughout
- **3a / 8 / 9a** LAN 192.168.1.0/24 (gw .1), server LAN 192.168.2.0/24, server 192.168.2.2
- **4a** VLAN 10 → 192.168.10.1–.4, VLAN 20 → 192.168.20.1–.4 /24
- **4b(a)** VLAN 10 → 192.168.10.1/.2, VLAN 20 → 192.168.20.1/.2; SVI gateways .10.100 and .20.100
- **4b(b)** VLAN 10/20/30 → 192.168.10/20/30.1–.3; sub-interface gateways x.x.x.100
- **5a** PC0 10.0.0.2, PC1 20.20.20.2 /8; serial links 30.x, 40.x, 50.x; OSPF area 0
- **5b** LANs 192.168.10/20/30.0/24; serial links 10.0.0.0/8 and 20.0.0.0/8; RIP
- **6** 192.168.10.0/25 (hosts .1–.3, gw .4) and 192.168.10.128/25 (hosts .129–.131, gw .132)
- **7** pools `10` (192.168.10.0/24) and `20` (192.168.20.0/24), excluded 192.168.10.3–.6
- **10** PC0 192.168.1.2, Laptop0 192.168.1.3, server 192.168.2.2, domain `kare.edu`

## Two things to do by hand

1. **Ex 10 — mailbox accounts.** The server has SMTP and POP3 on, the domain
   set to `kare.edu`, DNS records for `kare.edu` / `mail.kare.edu` /
   `www.kare.edu` / `ftp.kare.edu`, and FTP user `cisco`/`cisco`. The two
   mailboxes are *not* pre-created — adding `user1` and `user2` (password
   `cisco`) under **Server0 → Services → EMAIL** is step 4 of the written
   procedure. The mail clients on PC0 (`user1@kare.edu`) and Laptop0
   (`user2@kare.edu`) are already filled in, so once the two accounts exist,
   Compose → Send → Receive works straight away.
2. **Ex 7 — release/renew.** The PCs are set to DHCP and will pick up
   addresses as soon as the file loads. If a PC still shows 0.0.0.0, open
   **Desktop → IP Configuration**, click Static then DHCP again.

## Where these files differ from the manual, and why

The manual's tables contradict themselves in a few places. Each of these
files is built so the experiment actually works, staying as close to the
printed table as possible:

- **1a** keeps the printed default gateway 172.16.1.1 even though the
  topology has no router. Pings between PC0 and PC1 work (same /16); the
  gateway simply shows up in `ipconfig` as the table says.
- **4b(a)** the manual's table names PT-switch ports (Fa0/1, Fa1/1, Fa2/1)
  while its CLI listing uses 2960 ports (fa0/1, fa0/2, fa0/3). The CLI
  listing wins, so these are 2960 switches: PCs on Fa0/1 and Fa0/2, trunk on
  Fa0/3. Host gateways (.10.100 / .20.100) were added — the table omits
  them, and inter-VLAN ping cannot work without them.
- **5a** uses 2960 switches so the printed Fa0/1 and Fa0/2 port names match;
  **5b** uses PT switches so its printed Fa0/1 and Fa1/1 match.
- **6** puts both switch-to-router uplinks on Fa3/1. The manual gives
  Switch1's uplink as Fa2/1, which already has PC5 on it.
- **7** the router's Fa4/0 and Fa5/0 are fitted with copper modules, so the
  copper straight-through cables in the procedure can connect. A stock
  Router-PT has fiber in those slots. The same swap is done on the PT
  switches wherever the procedure cables Fa4/1.
- **10** the manual puts the server on 192.168.2.2/24 with gateway
  192.168.2.1 but configures only Fa0/0 192.168.1.1 on the router and one
  switch, so nothing could reach the server. The addresses are kept exactly
  as printed and the router is given Fa1/0 192.168.2.1 with a second switch
  for the server — which is also what the stated conclusion ("exchange
  messages across subnets") describes.
- **2b (ring, mesh)** spanning tree blocks the redundant links, as it should.
  `show spanning-tree` on any switch makes a good addition to the write-up.
- **3a, 8, 9a** are Windows-command / Wireshark experiments in the manual.
  The files give the Packet Tracer equivalent: 3a runs `ipconfig`, `ping`,
  `tracert`, `arp -a`, `netstat`, `nslookup` from a PC's Desktop → Command
  Prompt, and 8 and 9a are built for **Simulation mode** — switch to it,
  filter to ICMP (8) or TCP/HTTP/DNS (9a), then ping or browse
  `www.kare.edu` and open the PDU to read the headers the manual's tables
  ask for.
